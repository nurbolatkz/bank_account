from abc import ABC


class Model(ABC):
    ...

