#!/bin/sh
export pg_dbname=product
export pg_user=doadmin
export pg_password=e5Y6G88wWs0EGS5e
