from datetime import datetime
# import random
from dataclasses import dataclass
from decimal import Decimal
from typing import Optional
from uuid import UUID

from account.account import Account
import json


@dataclass
class Transaction:
    id_: UUID
    sender: Account
    receiver: Account
    amount: Decimal = 0
    date: str = str(datetime.now())
    type: int = 0
    commission: float = 0

    def withdraw(self, amount, typeOfTransfer) -> None:
        if amount > self.sender.balance:
            raise ValueError("insufficient funds")
        # 0 if between user and bank accounts, 1 if other bank accounts, 2 if international transfers
        if typeOfTransfer == 0:
            self.commission = 0
        elif typeOfTransfer == 1:
            self.commission = 5
        else:
            self.commission = 15

        self.sender.balance -= (amount + (self.commission * amount))
        self.date = str(datetime.now())
        self.type = typeOfTransfer

    def add_balance(self, amount) -> None:
        self.receiver.balance += amount

    def transfer(self, amount) -> None:
        self.withdraw(amount, 0)
        self.amount = amount
        self.add_balance(amount)

    def to_json(self) -> str:
        json_repr = {
            "id_": str(self.id_),
            "sender": str(self.sender.id_),
            "receiver": str(self.receiver.id_),
            "amount": float(self.amount),
            "date": self.date,
            "type": int(self.type),
            "commission": float(self.commission),

        }
        return json.dumps(json_repr)













