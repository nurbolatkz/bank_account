from decimal import Decimal
from uuid import uuid4, UUID

import pytest
import json

from account.account import Account
from transaction.transaction import Transaction

class TestTransaction:

    def test_transaction_create(self) -> None:
        account1 = Account.random()
        account2 = Account.random()
        transaction = Transaction(
            id_=uuid4(),
            sender=account1,
            receiver=account2,
        )
        assert isinstance(transaction, Transaction)
        assert transaction.amount == 0
        assert account1.id_ == transaction.sender.id_
        assert account2.id_ == transaction.receiver.id_

    def test_withdraw(self) -> None:
        account1 = Account.random()

        account2 = Account.random()
        transaction = Transaction(
            id_=uuid4(),
            sender=account1,
            receiver=account2,
        )
        account1.balance = 500
        transaction.withdraw(200, 0)
        assert account1.balance == 300

    def test_transfer(self) -> None:
        account1 = Account.random()
        account2 = Account.random()

        transaction = Transaction(
            id_=uuid4(),
            sender=account1,
            receiver=account2,
        )
        account1.balance = 1000
        account2.balance = 600
        transaction.transfer(200)

        assert account1.balance == 800
        assert account2.balance == 800

    def test_to_json(self) -> None:
        account1 = Account.random()
        account2 = Account.random()

        transaction = Transaction(
            id_=uuid4(),
            sender=account1,
            receiver=account2,
        )
        json_str = transaction.to_json()
        assert json.loads(json_str) == {
            "id_": str(transaction.id_),
            "sender": str(transaction.sender.id_),
            "receiver": str(transaction.receiver.id_),
            "amount": float(transaction.amount),
            "date": transaction.date,
            "type": int(transaction.type),
            "commission": float(transaction.commission),

        }










